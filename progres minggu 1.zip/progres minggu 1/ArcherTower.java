public class ArcherTower extends DefenseBuilding {

    public ArcherTower(int level) {
        super("Archer Tower", 150 + (level * 40), 20 + (level * 8), level);
    }

    @Override
    public void attack(Troop troop) {
        System.out.println("Archer Tower menembak " + troop.name);
        troop.takeDamage(damage);
    }
}
