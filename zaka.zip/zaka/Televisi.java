public class Televisi {
    // ====== 10 Atribut ======
    public String merk;
    private int ukuranInch;
    protected String resolusi;
    private boolean smartTV;
    private int volume;
    private int channel;
    private String warna;
    private int tahunProduksi;
    private double harga;
    private boolean powerOn;

    // ====== Constructor ======
    public Televisi(String merk, int ukuranInch, String resolusi, boolean smartTV,
                    int volume, int channel, String warna, int tahunProduksi, double harga) {
        this.merk = merk;
        this.ukuranInch = ukuranInch;
        this.resolusi = resolusi;
        this.smartTV = smartTV;
        this.volume = volume;
        this.channel = channel;
        this.warna = warna;
        this.tahunProduksi = tahunProduksi;
        this.harga = harga;
        this.powerOn = false;
    }

    // ====== Method ======
    public void nyalakan() {
        powerOn = true;
        System.out.println(merk + " menyala");
    }

    public void matikan() {
        powerOn = false;
        System.out.println(merk + " dimatikan");
    }

    public void volumeUp() {
        volume++;
        System.out.println("Volume : " + volume);
    }

    public void volumeDown() {
        if (volume > 0) volume--;
        System.out.println("Volume : " + volume);
    }

    public void channelUp() {
        channel++;
        System.out.println("Channel : " + channel);
    }

    public void channelDown() {
        if (channel > 1) channel--;
        System.out.println("Channel : " + channel);
    }

    public void infoTelevisi() {
        System.out.println("Merk : " + merk);
        System.out.println("Ukuran Inch : " + ukuranInch);
        System.out.println("Resolusi : " + resolusi);
        System.out.println("Smart TV : " + smartTV);
        System.out.println("Volume : " + volume);
        System.out.println("Channel : " + channel);
        System.out.println("Warna : " + warna);
        System.out.println("Tahun Produksi : " + tahunProduksi);
        System.out.println("Harga : Rp" + harga);
    }

    public String getMerk() {
        return merk;
    }

    private void factoryReset() {
        volume = 10;
        channel = 1;
        System.out.println("TV direset ke setelan pabrik");
    }

    protected void updateFirmware() {
        System.out.println("Firmware " + merk + " berhasil diupdate");
    }

    public void demoFiturRahasia() {
        factoryReset();
    }
}