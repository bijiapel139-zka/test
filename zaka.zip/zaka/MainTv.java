public class MainTv {
     public static void main(String[] args) {
        // Buat beberapa objek Televisi
        Televisi tv1 = new Televisi("Samsung", 55, "4K", true, 100, 20, "Hitam", 2019, 25000000);
        Televisi tv2 = new Televisi("LG", 43, "Full HD", true, 100, 24, "Silver", 2023, 5500000);

        // Tes method
        tv1.nyalakan();
        tv1.channelUp();
        tv1.volumeUp();
        tv1.infoTelevisi();

        System.out.println();

        tv2.nyalakan();
        tv2.updateFirmware();
        tv2.demoFiturRahasia();
        tv2.infoTelevisi();
    }
}
    

