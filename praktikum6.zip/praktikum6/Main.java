public class Main {

    public static void main(String[] args) {

        BinarySearchTree bst = new BinarySearchTree();

        bst.root = bst.insert(bst.root, 50);
        bst.root = bst.insert(bst.root, 30);
        bst.root = bst.insert(bst.root, 70);
        bst.root = bst.insert(bst.root, 20);
        bst.root = bst.insert(bst.root, 40);
        bst.root = bst.insert(bst.root, 60);
        bst.root = bst.insert(bst.root, 80);

        System.out.println("Traversal Inorder:");
        bst.inorder(bst.root);

        int cari = 40;

        if (bst.search(bst.root, cari)) {
            System.out.println("\nData " + cari + " ditemukan");
        } else {
            System.out.println("\nData " + cari + " tidak ditemukan");
        }
    }
}