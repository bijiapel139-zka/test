public class User {
    private String nama;
    private String id;
    private String email;
    //construktor
    public User (String nama,String id,String email){
        this.nama = nama;
        this.id = id;
        this.email = email;
    }
    //getter & setter
    public String getNama(){
        return this.nama;
    }
    public void setNama(String nama){
        this.nama = nama;
    }
    public String getId(){
        return this.id;
    }
    public void setid(String id){
        this.id = id;
    }

    public String getEmail(){
        return this.email;
    }
    public void setEmail(String email){
        this.email = email;
    }
    public void kelolaDataPribadi(){
        System.out.println(nama+"sedang mengelola data pribadi");
    }
}
