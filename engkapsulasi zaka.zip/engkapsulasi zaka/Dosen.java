public class Dosen extends User{
    public Dosen(String username, String id, String email){
        super(username, id, email);
    }
    public void kelolaNilai(Mahasiswa m,int nilai){
        System.out.println("Dosen menginput nilai"+nilai+"untuk mahasiswa"+m.getNama());
        m.setNilai(nilai);
    }
    
}
