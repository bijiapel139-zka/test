public  class Kaprodi extends User {
    public Kaprodi(String nama, String id, String email){
        super(nama,id,email);
    }
    public void kelolaKelas(String namaKelas){
        System.out.println("kaprodi mengelola kelas"+namaKelas);
    }
    
}
