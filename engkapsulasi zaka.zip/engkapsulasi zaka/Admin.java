public class Admin extends User {
    public Admin( String nama,String id,String email){
        super(nama,id,email);
    }
    public void kelolaUser(User u){
        System.out.println("Admin mengelola data User "+u.getNama());
    }
}
