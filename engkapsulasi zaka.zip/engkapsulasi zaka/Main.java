public class Main {
    public static void main(String[] args) {
        
    
    Admin admin=new Admin("supri","A004","admin@kampus.ac.id");
    Dosen dosen=new Dosen("bapak harun","D993","harun@kampus.ac.id");
    Kaprodi kaprodi=new Kaprodi("bapak mulyono","K001","mulyono@kampus.ac.id");
    Mahasiswa mahasiswa=new Mahasiswa("zaka","M001","zaka@kampus.ac.id");

    //hak akses admin
    System.out.println("\n== Hak akses admin ==");
    admin.kelolaUser(dosen);
    admin.kelolaUser(kaprodi);
    admin.kelolaUser(mahasiswa);

    //hak akses dosen
    System.out.println("\n== Hak akses dosen ==");
    dosen.kelolaDataPribadi();
    dosen.kelolaNilai(mahasiswa,80);

    //hak akses kaprodi
    System.out.println("\n== Hak akses kaprodi ==");
    kaprodi.kelolaDataPribadi();
    kaprodi.kelolaKelas("pemprograman oop ");

    //hak akses mahasiswa
    System.out.println("\n== Hak akses mahasiswa ==");
    mahasiswa.kelolaDataPribadi();
    mahasiswa.lihatNilai();



    }
}
