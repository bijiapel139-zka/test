public class Mahasiswa extends User{
    private int nilai;
    public Mahasiswa(String nama,String id, String email){
        super(nama,id,email);
    }
    public void lihatNilai(){
        System.out.println(getNama()+"melihat nilai:"+nilai);
    }
    public void setNilai(int nilai){
        this.nilai=nilai;
    }
}
