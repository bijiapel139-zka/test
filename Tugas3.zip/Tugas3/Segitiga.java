package Tugas3;

public class Segitiga  extends BangunDatar{
    float alas;
    float tinggi;

    public Segitiga(int i, int j) {
        //TODO Auto-generated constructor stub
    }

    public float luas() {
    
        return (alas * tinggi) / 2;
    }

    public float keliling(){
        float sisiMiring = (float) Math.sqrt(alas * alas + tinggi * tinggi);
        return alas + 2 * sisiMiring;
    }
}

