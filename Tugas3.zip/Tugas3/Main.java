package Tugas3;

public class Main {
    public static void main(String[] args) {
        Persegi p = new Persegi(5);
        Lingkaran l = new Lingkaran(7);
        PersegiPanjang pp = new PersegiPanjang(4, 6);
        Segitiga s = new Segitiga(4, 5);

        System.out.println("Persegi:");
        System.out.println("Luas = " + p.luas());
        System.out.println("Keliling = " + p.keliling());

        System.out.println("\nLingkaran:");
        System.out.println("Luas = " + l.luas());
        System.out.println("Keliling = " + l.keliling());

        System.out.println("\nPersegi Panjang:");
        System.out.println("Luas = " + pp.luas());
        System.out.println("Keliling = " + pp.keliling());

        System.out.println("\nSegitiga:");
        System.out.println("Luas = " + s.luas());
        System.out.println("Keliling (asumsi sama kaki) = " + s.keliling());
    }
}
